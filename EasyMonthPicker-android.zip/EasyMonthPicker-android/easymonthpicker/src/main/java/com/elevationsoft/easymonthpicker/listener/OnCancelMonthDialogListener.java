package com.hvyas.easymonthpicker.listener;

import android.support.v7.app.AlertDialog;


public interface OnCancelMonthDialogListener {
     void onCancel(AlertDialog dialog);
}
